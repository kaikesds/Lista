package ListaDuplamenteEncadeada;


import Nodo.Nodo;
import com.mycompany.lista.Cliente;


public class ListaDuplamenteEncadeada {
    private Nodo cabeca;
    private Nodo cauda;

    public ListaDuplamenteEncadeada() {
        this.cabeca = null;
        this.cauda = null;
    }

    public void adicionarCliente(Cliente cliente) {
        Nodo novoNodo = new Nodo(cliente);
        if (cabeca == null) {
            cabeca = cauda = novoNodo;
        } else {
            cauda.setProximo(novoNodo);
            novoNodo.setAnterior(cauda);
            cauda = novoNodo;
        }
    }

    public Cliente excluirCliente(int codigo) {
        Nodo nodoAtual = cabeca;
        while (nodoAtual != null) {
            if (nodoAtual.getCliente().getCodigo() == codigo) {
                if (nodoAtual.getAnterior() != null) {
                    nodoAtual.getAnterior().setProximo(nodoAtual.getProximo());
                } else {
                    cabeca = nodoAtual.getProximo();
                }
                if (nodoAtual.getProximo() != null) {
                    nodoAtual.getProximo().setAnterior(nodoAtual.getAnterior());
                } else {
                    cauda = nodoAtual.getAnterior();
                }
                return nodoAtual.getCliente();
            }
            nodoAtual = nodoAtual.getProximo();
        }
        return null;
    }

    public Cliente alterarCliente(int codigo, String novoNome, String novaDataNascimento, String novoTelefone) {
        Nodo nodoAtual = cabeca;
        while (nodoAtual != null) {
            if (nodoAtual.getCliente().getCodigo() == codigo) {
                nodoAtual.getCliente().setNome(novoNome);
                nodoAtual.getCliente().setDataNascimento(novaDataNascimento);
                nodoAtual.getCliente().setTelefone(novoTelefone);
                return nodoAtual.getCliente();
            }
            nodoAtual = nodoAtual.getProximo();
        }
        return null;
    }

    public Cliente recuperarCliente(int codigo) {
        Nodo nodoAtual = cabeca;
        while (nodoAtual != null) {
            if (nodoAtual.getCliente().getCodigo() == codigo) {
                return nodoAtual.getCliente();
            }
            nodoAtual = nodoAtual.getProximo();
        }
        return null;
    }

    public String exibirTodosClientes() {
        StringBuilder sb = new StringBuilder();
        Nodo nodoAtual = cabeca;
        while (nodoAtual != null) {
            sb.append(nodoAtual.getCliente().toString()).append("\n");
            nodoAtual = nodoAtual.getProximo();
        }
        return sb.toString();
    }
}
