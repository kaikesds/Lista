
package Nodo;

import com.mycompany.lista.Cliente;


public class Nodo {
    private Cliente cliente;
    private Nodo anterior;
    private Nodo proximo;

    public Nodo(Cliente cliente) {
        this.cliente = cliente;
        this.anterior = null;
        this.proximo = null;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Nodo getAnterior() {
        return anterior;
    }

    public void setAnterior(Nodo anterior) {
        this.anterior = anterior;
    }

    public Nodo getProximo() {
        return proximo;
    }

    public void setProximo(Nodo proximo) {
        this.proximo = proximo;
    }
}
    

